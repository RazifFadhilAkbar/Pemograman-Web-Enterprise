import * as dotenv from 'dotenv';
dotenv.config();

console.info("Ini isi ENV -->>>", process.env.TOKEN);